<header class="absolute top-8 w-full px-8">
    <div class="w-full bg-white shadow rounded-lg border border-black px-6 py-4 mx-auto">
        <div class="lg:flex lg:items-center lg:justify-between">
            <div class="flex items-center justify-between">
                <a href="#">
                    <img class="w-auto h-6 sm:h-7" src="https://merakiui.com/images/full-logo.svg" alt="">
                </a>
            </div>
            <div class="w-full flex justify-end items-center">
                <h2 class="text-xl font-bold">Lecture PAGE</h2>
            </div>
        </div>
    </div>
</header>
